package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletResponse;
import javax.servlet.ServletRequest;
import bo.chitiethoadonbo;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet({ "/adminxacnhanController" })
public class adminxacnhanController extends HttpServlet
{
    private static final long serialVersionUID = 1L;
    
    protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        try {
            final String mact = request.getParameter("mact");
            final String tab = request.getParameter("tab");
            final chitiethoadonbo cthdbo = new chitiethoadonbo();
            if (mact != null && tab != null) {
                if (tab.equals("sua")) {
                    cthdbo.sua(Long.parseLong(mact));
                }
                else if (tab.equals("xoa")) {
                    cthdbo.xoa(Long.parseLong(mact));
                }
            }
            request.setAttribute("ds", (Object)cthdbo.getxacnhan());
            final RequestDispatcher rd = request.getRequestDispatcher("adminhoadon.jsp");
            rd.forward((ServletRequest)request, (ServletResponse)response);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
    }
}