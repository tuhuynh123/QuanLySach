package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;
import javax.servlet.ServletResponse;
import javax.servlet.ServletRequest;
import bo.CGioHang;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet({ "/tralaiController" })
public class tralaiController extends HttpServlet
{
    private static final long serialVersionUID = 1L;
    
    protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        try {
            final HttpSession session = request.getSession();
            final CGioHang g = (CGioHang)session.getAttribute("gh");
            final String[] th = request.getParameterValues("chonHang");
            if (request.getParameter("Xoatatca") != null) {
                if (g != null) {
                    g.XoaTatCa();
                    session.setAttribute("gh", (Object)g);
                }
            }
            else if (th != null) {
                g.XoaDaChon(th);
            }
            else {
                final String ms = request.getParameter("ms");
                if (ms != null && g != null) {
                    g.Xoa(ms);
                }
            }
            final RequestDispatcher rd = request.getRequestDispatcher("htgio.jsp");
            rd.forward((ServletRequest)request, (ServletResponse)response);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }
}