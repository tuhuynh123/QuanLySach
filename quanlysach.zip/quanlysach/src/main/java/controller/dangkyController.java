package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import javax.servlet.RequestDispatcher;
import bo.khachhangbo;
import javax.servlet.ServletResponse;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet({ "/dangkyController" })
public class dangkyController extends HttpServlet
{
    private static final long serialVersionUID = 1L;
    
    protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        try {
            request.setCharacterEncoding("UTF-8");
            response.setCharacterEncoding("UTF-8");
            final String hoten = request.getParameter("txtname");
            final String diachi = request.getParameter("txtdiachi");
            final String sdt = request.getParameter("txtsdt");
            final String email = request.getParameter("txtemail");
            final String tendn = request.getParameter("txttk");
            final String mk = request.getParameter("txtmk");
            if (hoten == null && diachi == null && sdt == null && email == null && tendn == null && mk == null) {
                final RequestDispatcher rd = request.getRequestDispatcher("dangky.jsp");
                rd.forward((ServletRequest)request, (ServletResponse)response);
            }
            else {
                final khachhangbo khbo = new khachhangbo();
                if (khbo.kttk(tendn) == null) {
                    khbo.them(hoten, diachi, sdt, email, tendn, mk);
                    final HttpSession session = request.getSession();
                    session.setAttribute("dn", (Object)khbo.kttk(tendn));
                    response.sendRedirect("sachController");
                }
                else {
                    request.setAttribute("errorMessage", (Object)"T\u00ean \u0111\u0103ng nh\u1eadp \u0111\u00e3 t\u1ed3n t\u1ea1i, vui l\u00f2ng ch\u1ecdn t\u00ean kh\u00e1c.");
                    final RequestDispatcher rd2 = request.getRequestDispatcher("dangky.jsp");
                    rd2.forward((ServletRequest)request, (ServletResponse)response);
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }
}