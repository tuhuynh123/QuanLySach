package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import java.util.Iterator;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;
import bean.lichsubean;
import java.util.ArrayList;
import bo.lichsuhangbo;
import javax.servlet.ServletResponse;
import javax.servlet.ServletRequest;
import bean.khachhangbean;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet({ "/lichsuController" })
public class lichsuController extends HttpServlet
{
    private static final long serialVersionUID = 1L;
    
    protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        try {
            request.setCharacterEncoding("UTF-8");
            response.setCharacterEncoding("UTF-8");
            final HttpSession session = request.getSession();
            final khachhangbean kh = (khachhangbean)session.getAttribute("dn");
            if (kh == null) {
                final RequestDispatcher rd = request.getRequestDispatcher("sachController?hdn=ok");
                rd.forward((ServletRequest)request, (ServletResponse)response);
            }
            else {
                final lichsuhangbo sbo = new lichsuhangbo();
                sbo.xoahoadonchuatt(kh.getMakh(), 15);
                final ArrayList<lichsubean> dslsh = sbo.getlsu(kh.getMakh());
                final ArrayList<lichsubean> dslshchuatt = new ArrayList<lichsubean>();
                final ArrayList<lichsubean> dslshdatt = new ArrayList<lichsubean>();
                for (final lichsubean lsh : dslsh) {
                    if (lsh.isDamua()) {
                        dslshdatt.add(lsh);
                    }
                    else {
                        dslshchuatt.add(lsh);
                    }
                }
                request.setAttribute("dslshchuatt", (Object)dslshchuatt);
                request.setAttribute("dslshdatt", (Object)dslshdatt);
                final RequestDispatcher rd2 = request.getRequestDispatcher("lichsu.jsp");
                rd2.forward((ServletRequest)request, (ServletResponse)response);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }
}
