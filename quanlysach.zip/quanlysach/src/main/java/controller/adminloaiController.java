package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.RequestDispatcher;
import bean.loaibean;
import java.util.ArrayList;
import javax.servlet.ServletResponse;
import javax.servlet.ServletRequest;
import bo.loaibo;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet({ "/adminloaiController" })
public class adminloaiController extends HttpServlet
{
    private static final long serialVersionUID = 1L;
    
    protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        try {
            request.setCharacterEncoding("UTF-8");
            response.setCharacterEncoding("UTF-8");
            final String maloai = request.getParameter("txtmaloai");
            final String tenloai = request.getParameter("txttenloai");
            final loaibo lbo = new loaibo();
            final ArrayList<loaibean> ds = lbo.getloai();
            if (request.getParameter("butadd") != null) {
                lbo.themloai(maloai, tenloai);
            }
            else if (request.getParameter("butupdate") != null) {
                lbo.sualoai(maloai, tenloai);
            }
            else {
                final String tab = request.getParameter("tab");
                final String ml = request.getParameter("ml");
                if (tab != null) {
                    if (tab.equals("select")) {
                        request.setAttribute("tenloai", (Object)lbo.Tim(ml));
                        request.setAttribute("maloai", (Object)ml);
                    }
                    else {
                        lbo.xoaloai(maloai);
                    }
                }
            }
            request.setAttribute("ds", (Object)lbo.getloai());
            final RequestDispatcher rd = request.getRequestDispatcher("adminloai.jsp");
            rd.forward((ServletRequest)request, (ServletResponse)response);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }
}
