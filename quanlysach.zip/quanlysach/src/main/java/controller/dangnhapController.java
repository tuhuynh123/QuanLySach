package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import bean.khachhangbean;
import javax.servlet.RequestDispatcher;
import bo.khachhangbo;
import javax.servlet.ServletResponse;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet({ "/dangnhapController" })
public class dangnhapController extends HttpServlet
{
    private static final long serialVersionUID = 1L;
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	 try {
             final String un = request.getParameter("txtun");
             final String pass = request.getParameter("txtpass");
             if (un == null && pass == null) {
                 final RequestDispatcher rd = request.getRequestDispatcher("sachController");
                 rd.forward((ServletRequest)request, (ServletResponse)response);
             }
             else {
                 final khachhangbo dnbo = new khachhangbo();
                 final khachhangbean kh = dnbo.ktdn(un, pass);
                 if (kh != null) {
                     final HttpSession session = request.getSession();
                     session.setAttribute("dn", (Object)kh);
                     response.sendRedirect("sachController");
                 }
                 else {
                     final RequestDispatcher rd2 = request.getRequestDispatcher("sachController?tb=dangnhapsai");
                     rd2.forward((ServletRequest)request, (ServletResponse)response);
                 }
             }
         }
         catch (Exception e) {
             e.printStackTrace();
         }
     }
    
    protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }
}
