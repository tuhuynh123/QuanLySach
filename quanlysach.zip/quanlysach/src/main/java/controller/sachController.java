package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.RequestDispatcher;
import bean.sachbean;
import bean.loaibean;
import java.util.ArrayList;
import javax.servlet.ServletResponse;
import javax.servlet.ServletRequest;
import bo.sachbo;
import bo.loaibo;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet({ "/sachController" })
public class sachController extends HttpServlet
{
    private static final long serialVersionUID = 1L;
    
    protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
    	  try {
              final String hdn = request.getParameter("hdn");
              request.setCharacterEncoding("UTF-8");
              response.setCharacterEncoding("UTF-8");
              final loaibo lbo = new loaibo();
              final ArrayList<loaibean> dsloai = (ArrayList<loaibean>)lbo.getloai();
              final String ml = request.getParameter("ml");
              final String key = request.getParameter("txttim");
              final sachbo sbo = new sachbo();
              ArrayList<sachbean> dssach = (ArrayList<sachbean>)sbo.getsach();
              if (ml != null) {
                  dssach = (ArrayList<sachbean>)sbo.TimMa(ml);
              }
              else if (key != null) {
                  dssach = (ArrayList<sachbean>)sbo.Tim(key);
              }
              request.setAttribute("dsloai", (Object)dsloai);
              request.setAttribute("dssach", (Object)dssach);
              request.setAttribute("hdn", (Object)hdn);
              final RequestDispatcher rd = request.getRequestDispatcher("htsach.jsp");
              rd.forward((ServletRequest)request, (ServletResponse)response);
          }
          catch (Exception e) {
              e.printStackTrace();
          }
      }
    
    
    protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }
}