package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import java.util.Iterator;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;
import bean.chitietgiohang;
import bo.CGioHang;
import bo.chitiethoadonbo;
import bo.hoadonbo;
import javax.servlet.ServletResponse;
import javax.servlet.ServletRequest;
import bean.khachhangbean;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet({ "/xacnhanController" })
public class xacnhanController extends HttpServlet
{
    private static final long serialVersionUID = 1L;
    
    protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        try {
            final HttpSession session = request.getSession();
            final khachhangbean kh = (khachhangbean)session.getAttribute("dn");
            if (kh == null) {
                final RequestDispatcher rd = request.getRequestDispatcher("sachController?hdn=ok");
                rd.forward((ServletRequest)request, (ServletResponse)response);
            }
            else {
                final hoadonbo hdbo = new hoadonbo();
                final chitiethoadonbo ctbo = new chitiethoadonbo();
                hdbo.themHD(kh.getMakh());
                final long maxhd = hdbo.MaxHD();
                final CGioHang g = (CGioHang)session.getAttribute("gh");
                for (final chitietgiohang h : g.ds) {
                    ctbo.themCTHD(h.getMasach(), h.getSoluong(), maxhd);
                }
                session.removeAttribute("gh");
                response.sendRedirect("lichsuController");
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }
}
