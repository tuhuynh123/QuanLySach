package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;
import javax.servlet.ServletResponse;
import javax.servlet.ServletRequest;
import bo.CGioHang;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet({ "/capnhatController" })
public class capnhatController extends HttpServlet
{
    private static final long serialVersionUID = 1L;
    
    protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        try {
            final HttpSession session = request.getSession();
            if (session.getAttribute("gh") != null) {
                final CGioHang g = (CGioHang)session.getAttribute("gh");
                if (g != null) {
                    final String ms = request.getParameter("ms");
                    final String sl = request.getParameter("txtsua");
                    if (ms != null && sl != null) {
                        g.Sua(ms, Integer.parseInt(sl));
                        session.setAttribute("gh", (Object)g);
                        response.sendRedirect("gioController");
                    }
                }
            }
            final RequestDispatcher rd = request.getRequestDispatcher("htgio.jsp");
            rd.forward((ServletRequest)request, (ServletResponse)response);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }
}
