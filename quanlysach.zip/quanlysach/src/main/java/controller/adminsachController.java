package controller;

import java.util.Iterator;
import java.util.List;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.FileItem;
import java.io.File;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.RequestDispatcher;
import bean.sachbean;
import java.util.ArrayList;
import javax.servlet.ServletResponse;
import javax.servlet.ServletRequest;
import bo.sachbo;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet({ "/adminsachController" })
public class adminsachController extends HttpServlet
{
    private static final long serialVersionUID = 1L;
    
    protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        try {
            request.setCharacterEncoding("UTF-8");
            response.setCharacterEncoding("UTF-8");
            final String masach = request.getParameter("txtmasach");
            final String tensach = request.getParameter("txttensach");
            final String gia = request.getParameter("txtgia");
            final String sl = request.getParameter("txtsoluong");
            final String tacgia = request.getParameter("txttacgia");
            final String anh = request.getParameter("txtanh");
            final String maloai = request.getParameter("txtmaloai");
            final sachbo sbo = new sachbo();
            final ArrayList<sachbean> ds = sbo.getsach();
            final String tab = request.getParameter("tab");
            final String ms = request.getParameter("masach");
            if (tab != null) {
                if (tab.equals("select")) {
                    final sachbean selectedSach = sbo.finByMS(masach);
                    if (selectedSach != null) {
                        request.setAttribute("tensach", (Object)selectedSach.getTensach());
                        request.setAttribute("masach", (Object)masach);
                        request.setAttribute("tacgia", (Object)selectedSach.getTacgia());
                        request.setAttribute("sl", (Object)sl);
                        request.setAttribute("gia", (Object)gia);
                        request.setAttribute("maloai", (Object)maloai);
                        request.setAttribute("anh", (Object)anh);
                    }
                }
                else if (ms != null && !ms.isEmpty()) {
                    sbo.xoaSach(ms);
                }
            }
            request.setAttribute("dss", (Object)sbo.getsach());
            final RequestDispatcher rd = request.getRequestDispatcher("adminsach.jsp");
            rd.forward((ServletRequest)request, (ServletResponse)response);
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        final DiskFileItemFactory factory = new DiskFileItemFactory();
        final DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();
        final ServletFileUpload upload = new ServletFileUpload((FileItemFactory)fileItemFactory);
        final String dirUrl1 = String.valueOf(request.getServletContext().getRealPath("")) + File.separator + "image_sach";
        response.getWriter().println(dirUrl1);
        System.out.println(dirUrl1);
        final sachbo sbo = new sachbo();
        String masach = null;
        String tensach = null;
        String tacgia = null;
        String sl = null;
        String gia = null;
        String maloai = null;
        String anh = null;
        String tab = null;
        String btnadd = null;
        String btnupdate = null;
        try {
            final List<FileItem> fileItems = (List<FileItem>)upload.parseRequest(request);
            for (final FileItem fileItem : fileItems) {
                if (!fileItem.isFormField()) {
                    final String nameimg = fileItem.getName();
                    if (nameimg.equals("")) {
                        continue;
                    }
                    final String dirUrl2 = String.valueOf(request.getServletContext().getRealPath("")) + File.separator + "image_sach";
                    final File dir = new File(dirUrl2);
                    if (!dir.exists()) {
                        dir.mkdir();
                    }
                    final String fileImg = String.valueOf(dirUrl2) + File.separator + nameimg;
                    anh = "image_sach/" + nameimg;
                    response.getWriter().println(fileImg);
                    final File file = new File(fileImg);
                    try {
                        fileItem.write(file);
                        System.out.println("UPLOAD TH\u00c0NH C\u00d4NG...!");
                        System.out.println("\u0110\u01b0\u1eddng d\u1eabn l\u01b0u file l\u00e0: " + dirUrl2);
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                else {
                    final String tentk = fileItem.getFieldName();
                    if (tentk.equals("txtmasach")) {
                        masach = fileItem.getString();
                    }
                    if (tentk.equals("txttensach")) {
                        tensach = fileItem.getString();
                    }
                    if (tentk.equals("txttacgia")) {
                        tacgia = fileItem.getString();
                    }
                    if (tentk.equals("txtsoluong")) {
                        sl = fileItem.getString();
                    }
                    if (tentk.equals("txtgia")) {
                        gia = fileItem.getString();
                    }
                    if (tentk.equals("txtmaloai")) {
                        maloai = fileItem.getString();
                    }
                    if (tentk.equals("tab")) {
                        tab = fileItem.getString();
                    }
                    if (tentk.equals("butadd")) {
                        btnadd = fileItem.getString();
                    }
                    if (!tentk.equals("butupdate")) {
                        continue;
                    }
                    btnupdate = fileItem.getString();
                }
            }
            if (btnadd != null) {
                System.out.print(anh);
                sbo.themSach(masach, tensach, tacgia, Long.parseLong(gia), Long.parseLong(sl), anh, maloai);
            }
            else if (btnupdate != null) {
                sbo.suaSach(masach, tensach, tacgia, Long.parseLong(gia), Long.parseLong(sl), anh, maloai);
            }
            response.sendRedirect("adminsachController");
        }
        catch (FileUploadException e2) {
            System.out.println(e2.getMessage());
        }
        catch (NumberFormatException e3) {
            System.out.println(e3.getMessage());
        }
        catch (Exception e4) {
            System.out.println(e4.getMessage());
        }
    }
}
