package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;
import bean.loaibean;
import java.util.ArrayList;
import javax.servlet.ServletResponse;
import javax.servlet.ServletRequest;
import bo.CGioHang;
import bo.loaibo;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet({ "/gioController" })
public class gioController extends HttpServlet
{
    private static final long serialVersionUID = 1L;
    
    protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        try {
            final loaibo lbo = new loaibo();
            final ArrayList<loaibean> dsloai = lbo.getloai();
            request.setAttribute("dsloai", (Object)dsloai);
            final String ms = request.getParameter("ms");
            final String ts = request.getParameter("ts");
            final String gia = request.getParameter("gia");
            final String sl = request.getParameter("sl");
            final String anh = request.getParameter("anh");
            final HttpSession session = request.getSession();
            if (ms != null && ts != null && gia != null && sl != null && anh != null) {
                CGioHang gh = (CGioHang)session.getAttribute("gh");
                if (gh == null) {
                    gh = new CGioHang();
                    session.setAttribute("gh", (Object)gh);
                }
                gh = (CGioHang)session.getAttribute("gh");
                gh.Them(ms, ts, Integer.parseInt(gia), 1, anh);
                session.setAttribute("gh", (Object)gh);
                response.sendRedirect("gioController");
            }
            else {
                final RequestDispatcher rd = request.getRequestDispatcher("htgio.jsp");
                rd.forward((ServletRequest)request, (ServletResponse)response);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }
}
