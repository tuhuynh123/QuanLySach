package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;
import bean.admindangnhapbean;
import javax.servlet.ServletResponse;
import javax.servlet.ServletRequest;
import bo.admindangnhapbo;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet({ "/admindangnhapController" })
public class admindangnhapController extends HttpServlet
{
    private static final long serialVersionUID = 1L;
    
    protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        try {
            final String un = request.getParameter("txtun");
            final String pass = request.getParameter("txtpass");
            RequestDispatcher rd;
            if (un != null && pass != null) {
                final admindangnhapbo dnbo = new admindangnhapbo();
                final admindangnhapbean dn = dnbo.ktdn(un, pass);
                if (dn != null) {
                    final HttpSession session = request.getSession();
                    session.setAttribute("admin", (Object)dn);
                    rd = request.getRequestDispatcher("adminController");
                }
                else {
                    rd = request.getRequestDispatcher("dangnhapadmin.jsp?kt=1");
                }
            }
            else {
                rd = request.getRequestDispatcher("dangnhapadmin.jsp");
            }
            rd.forward((ServletRequest)request, (ServletResponse)response);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }
}