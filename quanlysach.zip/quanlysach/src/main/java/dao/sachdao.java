package dao;

import java.sql.ResultSet;
import java.sql.PreparedStatement;
import bean.sachbean;
import java.util.ArrayList;

public class sachdao
{
    public ArrayList<sachbean> getsach() throws Exception {
        final ArrayList<sachbean> ds = new ArrayList<sachbean>();
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sql = "SELECT * FROM sach";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        final ResultSet rs = cmd.executeQuery();
        while (rs.next()) {
            final String masach = rs.getString("masach");
            final String tensach = rs.getString("tensach");
            final String tacgia = rs.getString("tacgia");
            final long gia = rs.getLong("gia");
            final long soluong = rs.getLong("soluong");
            final String anh = rs.getString("anh");
            final String maloai = rs.getString("maloai");
            ds.add(new sachbean(masach, tensach, tacgia, gia, soluong, anh, maloai));
        }
        rs.close();
        kn.cn.close();
        return ds;
    }
    
    public int themSach(final String masach, final String tensach, final String tacgia, final long gia, final long soluong, final String anh, final String maloai) throws Exception {
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sql = "INSERT INTO sach (masach, tensach, tacgia, gia, soluong, anh, maloai) VALUES (?, ?, ?, ?, ?, ?, ?)";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        cmd.setString(1, masach);
        cmd.setString(2, tensach);
        cmd.setString(3, tacgia);
        cmd.setLong(4, gia);
        cmd.setLong(5, soluong);
        cmd.setString(6, anh);
        cmd.setString(7, maloai);
        final int kq = cmd.executeUpdate();
        cmd.close();
        kn.cn.close();
        return kq;
    }
    
    public int suaSach(final String masach, final String tensach, final String tacgia, final long gia, final long soluong, final String anh, final String maloai) throws Exception {
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sql = "UPDATE sach SET tensach = ?, tacgia = ?, gia = ?, soluong = ?, anh = ?, maloai = ? WHERE masach = ?";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        cmd.setString(1, tensach);
        cmd.setString(2, tacgia);
        cmd.setLong(3, gia);
        cmd.setLong(4, soluong);
        cmd.setString(5, anh);
        cmd.setString(6, maloai);
        cmd.setString(7, masach);
        final int kq = cmd.executeUpdate();
        cmd.close();
        kn.cn.close();
        return kq;
    }
    
    public int xoaSach(final String masach) throws Exception {
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sql = "DELETE FROM sach WHERE masach = ?";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        cmd.setString(1, masach);
        final int kq = cmd.executeUpdate();
        cmd.close();
        kn.cn.close();
        return kq;
    }
}