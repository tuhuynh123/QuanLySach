package dao;

import java.sql.ResultSet;
import java.sql.PreparedStatement;
import bean.loaibean;
import java.util.ArrayList;

public class loaidao
{
    public ArrayList<loaibean> getloai() throws Exception {
        final ArrayList<loaibean> ds = new ArrayList<loaibean>();
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sql = "select * from loai";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        final ResultSet rs = cmd.executeQuery();
        while (rs.next()) {
            final String maloai = rs.getString("maloai");
            final String tenloai = rs.getString("tenloai");
            ds.add(new loaibean(maloai, tenloai));
        }
        rs.close();
        kn.cn.close();
        return ds;
    }
    
    public int themloai(final String maloai, final String tenloai) throws Exception {
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sql = "INSERT INTO loai (maloai, tenloai) VALUES (?, ?)";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        cmd.setString(1, maloai);
        cmd.setString(2, tenloai);
        final int kq = cmd.executeUpdate();
        cmd.close();
        kn.cn.close();
        return kq;
    }
    
    public int sualoai(final String maloai, final String tenloaimoi) throws Exception {
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sql = "UPDATE loai SET tenloai = ? WHERE maloai = ?";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        cmd.setString(1, tenloaimoi);
        cmd.setString(2, maloai);
        final int kq = cmd.executeUpdate();
        cmd.close();
        kn.cn.close();
        return kq;
    }
    
    public int xoaloai(final String maloai) throws Exception {
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sql = "DELETE FROM loai WHERE maloai = ?";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        cmd.setString(1, maloai);
        final int kq = cmd.executeUpdate();
        cmd.close();
        kn.cn.close();
        return kq;
    }
}