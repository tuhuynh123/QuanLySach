package dao;

import java.time.LocalDate;
import java.util.Date;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import bean.lichsubean;
import java.util.ArrayList;

public class lichsuhangdao
{
    public ArrayList<lichsubean> getlsu(final long makh) throws Exception {
        final ArrayList<lichsubean> ds = new ArrayList<lichsubean>();
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sql = "select * from viewmakh where makh=? order by NgayMua desc";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        cmd.setLong(1, makh);
        final ResultSet rs = cmd.executeQuery();
        while (rs.next()) {
            final String masach = rs.getString("masach");
            final String tensach = rs.getString("tensach");
            final int soluongmua = rs.getInt("soluongmua");
            final long gia = rs.getLong("gia");
            final long thanhtien = rs.getLong("thanhtien");
            final boolean damua = rs.getBoolean("damua");
            final Date ngaymua = rs.getDate("ngaymua");
            ds.add(new lichsubean(makh, masach, tensach, soluongmua, gia, thanhtien, damua, ngaymua));
        }
        rs.close();
        kn.cn.close();
        return ds;
    }
    
    public void xoahoadonchuatt(final long makh, final int daysAgo) throws Exception {
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final LocalDate expirationDate = LocalDate.now().minusDays(daysAgo);
        final String sql = "DELETE FROM hoadon WHERE damua = 0 AND makh = ? AND ngaymua < ?";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        cmd.setLong(1, makh);
        cmd.setDate(2, java.sql.Date.valueOf(expirationDate));
        cmd.executeUpdate();
        kn.cn.close();
    }
}
