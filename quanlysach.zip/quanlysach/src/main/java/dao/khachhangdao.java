package dao;

import java.sql.ResultSet;
import java.sql.PreparedStatement;
import bean.khachhangbean;

public class khachhangdao
{
    public khachhangbean ktdn(final String tendn, final String pass) throws Exception {
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sql = "select * from khachhang where tendn=? and pass=?";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        cmd.setString(1, tendn);
        cmd.setString(2, pass);
        final ResultSet rs = cmd.executeQuery();
        khachhangbean kh = null;
        if (rs.next()) {
            final long makh = rs.getLong("makh");
            final String hoten = rs.getString("hoten");
            final String diachi = rs.getString("diachi");
            final String sodt = rs.getString("sodt");
            final String email = rs.getString("email");
            kh = new khachhangbean(makh, hoten, diachi, sodt, email, tendn, pass);
        }
        return kh;
    }
    
    public long them(final String hoten, final String diachi, final String sodt, final String email, final String tendn, final String pass) throws Exception {
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sql = "INSERT INTO khachhang(hoten, diachi, sodt, email, tendn, pass) VALUES (?, ?, ?, ?, ?, ?)";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        cmd.setString(1, hoten);
        cmd.setString(2, diachi);
        cmd.setString(3, sodt);
        cmd.setString(4, email);
        cmd.setString(5, tendn);
        cmd.setString(6, pass);
        final long kq = cmd.executeUpdate();
        cmd.close();
        kn.cn.close();
        return kq;
    }
    
    public khachhangbean kttk(final String tendn) throws Exception {
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sql = "select * from khachhang where tendn=?";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        cmd.setString(1, tendn);
        final ResultSet rs = cmd.executeQuery();
        khachhangbean kh = null;
        if (rs.next()) {
            final long makh = rs.getLong("makh");
            final String hoten = rs.getString("hoten");
            final String diachi = rs.getString("diachi");
            final String sodt = rs.getString("sodt");
            final String email = rs.getString("email");
            final String pass = rs.getString("pass");
            kh = new khachhangbean(makh, hoten, diachi, sodt, email, tendn, pass);
        }
        return kh;
    }
}