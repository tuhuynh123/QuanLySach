package dao;

import bean.hoadonbean;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;

public class hoadondao
{
    public int themHD(final long makh) throws Exception {
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sql = "INSERT INTO hoadon(makh, NgayMua, damua) VALUES(?,?,?)";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        cmd.setLong(1, makh);
        final Date n = new Date();
        final SimpleDateFormat dd = new SimpleDateFormat("yyyy-MM-dd");
        final String nn = dd.format(n);
        final Date n2 = dd.parse(nn);
        cmd.setDate(2, new java.sql.Date(n2.getTime()));
        cmd.setBoolean(3, false);
        final int kq = cmd.executeUpdate();
        cmd.close();
        kn.cn.close();
        return kq;
    }
    
    public long MaxHD() throws Exception {
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sql = "SELECT MAX(MaHoaDon) as 'HDLD' FROM hoadon";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        final ResultSet rs = cmd.executeQuery();
        long max = 0L;
        if (rs.next()) {
            max = rs.getLong(1);
        }
        cmd.close();
        kn.cn.close();
        return max;
    }
    
    public hoadonbean timHD(final long mahd) throws Exception {
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sql = "SELECT * FROM hoadon WHERE MaHoaDon = ?";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        cmd.setLong(1, mahd);
        final ResultSet rs = cmd.executeQuery();
        hoadonbean hd = null;
        if (rs != null) {
            final long makh = rs.getLong("makh");
            final Date ngaymua = rs.getDate("ngaymua");
            final boolean damua = rs.getBoolean("damua");
            hd = new hoadonbean(mahd, makh, ngaymua, damua);
        }
        return hd;
    }
}