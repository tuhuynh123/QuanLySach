package dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class ketnoidao {
	public Connection cn;
	public void ketnoi() throws Exception{
		// b1 : xac dinh hqtcsdl
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		String url = "jdbc:sqlserver://TU\\SQLEXPRESS:1433;databaseName=QLSach;user=sa; password=123456;";
		cn=DriverManager.getConnection(url);
		System.out.print("Da ket noi duoc heqtcsdl");
	}
}