package dao;

import java.sql.ResultSet;
import java.sql.PreparedStatement;
import bean.admindangnhapbean;

public class admindangnhapdao
{
    public admindangnhapbean ktdn(final String tendn, final String pass) throws Exception {
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sql = "select * from DangNhap where TenDangNhap=? and MatKhau=?";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        cmd.setString(1, tendn);
        cmd.setString(2, pass);
        final ResultSet rs = cmd.executeQuery();
        admindangnhapbean dn = null;
        if (rs.next()) {
            final String TenDangNhap = rs.getString("TenDangNhap");
            final String MatKhau = rs.getString("MatKhau");
            final boolean Quyen = rs.getBoolean("Quyen");
            dn = new admindangnhapbean(TenDangNhap, MatKhau, Quyen);
        }
        return dn;
    }
}