package dao;

import java.sql.ResultSet;
import bean.adminxacnhanbean;
import java.util.ArrayList;
import java.sql.PreparedStatement;

public class chitiethoadondao
{
    public int ThemCTHD(final String masach, final long soluongmua, final long mahoadon) throws Exception {
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sql = "Insert into ChiTietHoaDon(MaSach,SoLuongMua,MaHoaDon,damua) values (?,?,?,?)";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        cmd.setString(1, masach);
        cmd.setLong(2, soluongmua);
        cmd.setLong(3, mahoadon);
        cmd.setBoolean(4, false);
        final int kq = cmd.executeUpdate();
        cmd.close();
        kn.cn.close();
        return kq;
    }
    
    public int xacnhanHoaDonVaChiTiet(final long mahoadon) throws Exception {
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sqlHoaDon = "UPDATE HoaDon SET damua = 1 WHERE MaHoaDon = ?";
        final PreparedStatement cmdHoaDon = kn.cn.prepareStatement(sqlHoaDon);
        cmdHoaDon.setLong(1, mahoadon);
        cmdHoaDon.executeUpdate();
        cmdHoaDon.close();
        final String sqlChiTiet = "UPDATE ChiTietHoaDon SET damua = 1 WHERE MaHoaDon = ?";
        final PreparedStatement cmdChiTiet = kn.cn.prepareStatement(sqlChiTiet);
        cmdChiTiet.setLong(1, mahoadon);
        cmdChiTiet.executeUpdate();
        cmdChiTiet.close();
        kn.cn.close();
        return 0;
    }
    
    public int sua(final long mact) throws Exception {
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sql = "UPDATE ChiTietHoaDon SET damua = 1 where MaChiTietHD = ?";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        cmd.setLong(1, mact);
        final int kq = cmd.executeUpdate();
        cmd.close();
        kn.cn.close();
        return kq;
    }
    
    public int xoa(final long mact) throws Exception {
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sql = "DELETE FROM ChiTietHoaDon WHERE MaChiTietHD = ?";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        cmd.setLong(1, mact);
        final int kq = cmd.executeUpdate();
        cmd.close();
        kn.cn.close();
        return kq;
    }
    
    public ArrayList<adminxacnhanbean> getxacnhan() throws Exception {
        final ArrayList<adminxacnhanbean> ds = new ArrayList<adminxacnhanbean>();
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sql = "select * from Vxacnhan";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        final ResultSet rs = cmd.executeQuery();
        while (rs.next()) {
            long MaChiTietHD = rs.getLong("MaChiTietHD");
            String hoten = rs.getString("hoten");
            String tensach = rs.getString("tensach");
            long gia = rs.getLong("gia");
            long SoLuongMua = rs.getLong("SoLuongMua");
            long thanhtien = rs.getLong("thanhtien");
            boolean damua = rs.getBoolean("damua");
            ds.add(new adminxacnhanbean(MaChiTietHD, hoten, tensach, gia, SoLuongMua, thanhtien, damua));
        }
        rs.close();
        kn.cn.close();
        return ds;
    }
}