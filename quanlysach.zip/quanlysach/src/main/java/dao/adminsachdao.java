package dao;

import java.util.Date;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import bean.adminsachbean;
import java.util.ArrayList;

public class adminsachdao
{
    public ArrayList<adminsachbean> getsachadmin() throws Exception {
        final ArrayList<adminsachbean> ds = new ArrayList<adminsachbean>();
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sql = "SELECT * FROM sach";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        final ResultSet rs = cmd.executeQuery();
        while (rs.next()) {
            final String masach = rs.getString("masach");
            final String tensach = rs.getString("tensach");
            final long soluong = rs.getLong("soluong");
            final long gia = rs.getLong("gia");
            final String tacgia = rs.getString("tacgia");
            final String anh = rs.getString("anh");
            final String maloai = rs.getString("maloai");
            final long sotap = rs.getLong("sotap");
            final Date ngayNhap = rs.getDate("ngayNhap");
            ds.add(new adminsachbean(masach, tensach, soluong, gia, maloai, sotap, anh, ngayNhap, tacgia, sotap));
        }
        rs.close();
        kn.cn.close();
        return ds;
    }
    
    public int themSach(final String masach, final String tensach, final long soluong, final long gia, final String maloai, final long sotap, final String anh, final Date ngayNhap, final String tacgia) throws Exception {
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sql = "INSERT INTO sach (masach, tensach, tacgia, gia, soluong, anh, maloai, sotap, ngayNhap) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        cmd.setString(1, masach);
        cmd.setString(2, tensach);
        cmd.setString(3, tacgia);
        cmd.setLong(4, gia);
        cmd.setLong(5, soluong);
        cmd.setString(6, anh);
        cmd.setString(7, maloai);
        cmd.setLong(8, sotap);
        cmd.setDate(9, new java.sql.Date(ngayNhap.getTime()));
        final int kq = cmd.executeUpdate();
        cmd.close();
        kn.cn.close();
        return kq;
    }
    
    public int suaSach(final String masach, final String tensach, final long soluong, final long gia, final String maloai, final long sotap, final String anh, final Date ngayNhap, final String tacgia) throws Exception {
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sql = "UPDATE sach SET tensach = ?, tacgia = ?, gia = ?, soluong = ?, anh = ?, maloai = ?, sotap = ?, ngayNhap = ? WHERE masach = ?";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        cmd.setString(1, tensach);
        cmd.setString(2, tacgia);
        cmd.setLong(3, gia);
        cmd.setLong(4, soluong);
        cmd.setString(5, anh);
        cmd.setString(6, maloai);
        cmd.setLong(7, sotap);
        cmd.setDate(8, new java.sql.Date(ngayNhap.getTime()));
        cmd.setString(9, masach);
        final int kq = cmd.executeUpdate();
        cmd.close();
        kn.cn.close();
        return kq;
    }
    
    public int xoaSach(final String masach) throws Exception {
        final ketnoidao kn = new ketnoidao();
        kn.ketnoi();
        final String sql = "DELETE FROM sach WHERE masach = ?";
        final PreparedStatement cmd = kn.cn.prepareStatement(sql);
        cmd.setString(1, masach);
        final int kq = cmd.executeUpdate();
        cmd.close();
        kn.cn.close();
        return kq;
    }
}
