package bean;

public class sachbean
{
    private String masach;
    private String tensach;
    private String tacgia;
    private long gia;
    private long soluong;
    private String anh;
    private String maloai;
    private long thanhtien;
    
    public sachbean() {
    }
    
    public sachbean(final String masach, final String tensach, final String tacgia, final long gia, final long soluong, final String anh, final String maloai) {
        this.masach = masach;
        this.tensach = tensach;
        this.tacgia = tacgia;
        this.gia = gia;
        this.soluong = soluong;
        this.anh = anh;
        this.maloai = maloai;
        this.thanhtien = gia * soluong;
    }
    
    public String getMasach() {
        return this.masach;
    }
    
    public void setMasach(final String masach) {
        this.masach = masach;
    }
    
    public String getTensach() {
        return this.tensach;
    }
    
    public void setTensach(final String tensach) {
        this.tensach = tensach;
    }
    
    public String getTacgia() {
        return this.tacgia;
    }
    
    public void setTacgia(final String tacgia) {
        this.tacgia = tacgia;
    }
    
    public long getGia() {
        return this.gia;
    }
    
    public void setGia(final long gia) {
        this.gia = gia;
    }
    
    public long getSoluong() {
        return this.soluong;
    }
    
    public void setSoluong(final long soluong) {
        this.soluong = soluong;
    }
    
    public String getAnh() {
        return this.anh;
    }
    
    public void setAnh(final String anh) {
        this.anh = anh;
    }
    
    public String getMaloai() {
        return this.maloai;
    }
    
    public void setMaloai(final String maloai) {
        this.maloai = maloai;
    }
    
    public long getThanhtien() {
        return this.thanhtien;
    }
    
    public void setThanhtien(final long thanhtien) {
        this.thanhtien = thanhtien;
    }
}
