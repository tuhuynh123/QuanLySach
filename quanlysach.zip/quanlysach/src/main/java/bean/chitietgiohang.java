package bean;

public class chitietgiohang
{
    private String masach;
    private String tensach;
    private int gia;
    private int soluong;
    private String anh;
    private long thanhtien;
    
    public chitietgiohang() {
    }
    
    public chitietgiohang(final String masach, final String tensach, final int gia, final int soluong, final String anh) {
        this.masach = masach;
        this.tensach = tensach;
        this.gia = gia;
        this.soluong = soluong;
        this.anh = anh;
        this.thanhtien = gia * soluong;
    }
    
    public String getMasach() {
        return this.masach;
    }
    
    public void setMasach(final String masach) {
        this.masach = masach;
    }
    
    public String getTensach() {
        return this.tensach;
    }
    
    public void setTensach(final String tensach) {
        this.tensach = tensach;
    }
    
    public int getGia() {
        return this.gia;
    }
    
    public void setGia(final int gia) {
        this.gia = gia;
    }
    
    public int getSoluong() {
        return this.soluong;
    }
    
    public void setSoluong(final int soluong) {
        this.soluong = soluong;
    }
    
    public String getAnh() {
        return this.anh;
    }
    
    public void setAnh(final String anh) {
        this.anh = anh;
    }
    
    public long getThanhtien() {
        return this.thanhtien;
    }
    
    public void setThanhtien(final long tt) {
        this.thanhtien = tt;
    }
}