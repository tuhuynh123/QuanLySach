package bean;

public class chitiethoadonbean
{
    private long MaChiTietHD;
    private String Masach;
    private int SoLuongMua;
    private long MaHoaDon;
    private boolean damua;
    
    public chitiethoadonbean() {
    }
    
    public chitiethoadonbean(final long maChiTietHD, final String masach, final int soLuongMua, final long maHoaDon, final boolean damua) {
        this.MaChiTietHD = maChiTietHD;
        this.Masach = masach;
        this.SoLuongMua = soLuongMua;
        this.MaHoaDon = maHoaDon;
        this.damua = damua;
    }
    
    public long getMaChiTietHD() {
        return this.MaChiTietHD;
    }
    
    public void setMaChiTietHD(final long maChiTietHD) {
        this.MaChiTietHD = maChiTietHD;
    }
    
    public String getMasach() {
        return this.Masach;
    }
    
    public void setMasach(final String masach) {
        this.Masach = masach;
    }
    
    public int getSoLuongMua() {
        return this.SoLuongMua;
    }
    
    public void setSoLuongMua(final int soLuongMua) {
        this.SoLuongMua = soLuongMua;
    }
    
    public long getMaHoaDon() {
        return this.MaHoaDon;
    }
    
    public void setMaHoaDon(final long maHoaDon) {
        this.MaHoaDon = maHoaDon;
    }
    
    public boolean isDamua() {
        return this.damua;
    }
    
    public void setDamua(final boolean damua) {
        this.damua = damua;
    }
}