package bean;

import java.util.Date;

public class lichsubean
{
    private long makh;
    private String masach;
    private String tensach;
    private int soluongmua;
    private long gia;
    private long thanhtien;
    private boolean damua;
    private Date ngaymua;
    
    public lichsubean() {
    }
    
    public lichsubean(final long makh, final String masach, final String tensach, final int soluongmua, final long gia, final long thanhtien, final boolean damua, final Date ngaymua) {
        this.makh = makh;
        this.masach = masach;
        this.tensach = tensach;
        this.soluongmua = soluongmua;
        this.gia = gia;
        this.thanhtien = thanhtien;
        this.damua = damua;
        this.ngaymua = ngaymua;
    }
    
    public long getMakh() {
        return this.makh;
    }
    
    public void setMakh(final long makh) {
        this.makh = makh;
    }
    
    public String getMasach() {
        return this.masach;
    }
    
    public void setMasach(final String masach) {
        this.masach = masach;
    }
    
    public String getTensach() {
        return this.tensach;
    }
    
    public void setTensach(final String tensach) {
        this.tensach = tensach;
    }
    
    public int getSoluongmua() {
        return this.soluongmua;
    }
    
    public void setSoluongmua(final int soluongmua) {
        this.soluongmua = soluongmua;
    }
    
    public long getGia() {
        return this.gia;
    }
    
    public void setGia(final long gia) {
        this.gia = gia;
    }
    
    public long getThanhtien() {
        return this.thanhtien;
    }
    
    public void setThanhtien(final long thanhtien) {
        this.thanhtien = thanhtien;
    }
    
    public boolean isDamua() {
        return this.damua;
    }
    
    public void setDamua(final boolean damua) {
        this.damua = damua;
    }
    
    public Date getNgaymua() {
        return this.ngaymua;
    }
    
    public void setNgaymua(final Date ngaymua) {
        this.ngaymua = ngaymua;
    }
}
