package bean;

public class khachhangbean
{
    private long makh;
    private String hoten;
    private String diachi;
    private String sodt;
    private String email;
    private String tendn;
    private String pass;
    
    public khachhangbean() {
    }
    
    public khachhangbean(final long makh, final String hoten, final String diachi, final String sodt, final String email, final String tendn, final String pass) {
        this.makh = makh;
        this.hoten = hoten;
        this.diachi = diachi;
        this.sodt = sodt;
        this.email = email;
        this.tendn = tendn;
        this.pass = pass;
    }
    
    public long getMakh() {
        return this.makh;
    }
    
    public void setMakh(final long makh) {
        this.makh = makh;
    }
    
    public String getHoten() {
        return this.hoten;
    }
    
    public void setHoten(final String hoten) {
        this.hoten = hoten;
    }
    
    public String getDiachi() {
        return this.diachi;
    }
    
    public void setDiachi(final String diachi) {
        this.diachi = diachi;
    }
    
    public String getSodt() {
        return this.sodt;
    }
    
    public void setSodt(final String sodt) {
        this.sodt = sodt;
    }
    
    public String getEmail() {
        return this.email;
    }
    
    public void setEmail(final String email) {
        this.email = email;
    }
    
    public String getTendn() {
        return this.tendn;
    }
    
    public void setTendn(final String tendn) {
        this.tendn = tendn;
    }
    
    public String getPass() {
        return this.pass;
    }
    
    public void setPass(final String pass) {
        this.pass = pass;
    }
}