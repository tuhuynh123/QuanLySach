package bean;

public class loaibean
{
    private String maloai;
    private String tenloai;
    
    public loaibean() {
    }
    
    public loaibean(final String maloai, final String tenloai) {
        this.maloai = maloai;
        this.tenloai = tenloai;
    }
    
    public String getMaloai() {
        return this.maloai;
    }
    
    public void setMaloai(final String maloai) {
        this.maloai = maloai;
    }
    
    public String getTenloai() {
        return this.tenloai;
    }
    
    public void setTenloai(final String tenloai) {
        this.tenloai = tenloai;
    }
}