package bean;

import java.util.Date;

public class hoadonbean
{
    private long MaHoaDon;
    private long makh;
    private Date NgayMua;
    private boolean damua;
    
    public hoadonbean() {
    }
    
    public hoadonbean(final long maHoaDon, final long makh, final Date ngayMua, final boolean damua) {
        this.MaHoaDon = maHoaDon;
        this.makh = makh;
        this.NgayMua = ngayMua;
        this.damua = damua;
    }
    
    public long getMaHoaDon() {
        return this.MaHoaDon;
    }
    
    public void setMaHoaDon(final long maHoaDon) {
        this.MaHoaDon = maHoaDon;
    }
    
    public long getMakh() {
        return this.makh;
    }
    
    public void setMakh(final long makh) {
        this.makh = makh;
    }
    
    public Date getNgayMua() {
        return this.NgayMua;
    }
    
    public void setNgayMua(final Date ngayMua) {
        this.NgayMua = ngayMua;
    }
    
    public boolean isDamua() {
        return this.damua;
    }
    
    public void setDamua(final boolean damua) {
        this.damua = damua;
    }
}