package bean;

public class adminxacnhanbean
{
    private long MaChiTietHD;
    private String hoten;
    private String tensach;
    private long gia;
    private long SoLuongMua;
    private long thanhtien;
    private boolean damua;
    
    public adminxacnhanbean() {
    }
    
    public adminxacnhanbean(final long maChiTietHD, final String hoten, final String tensach, final long gia, final long soLuongMua, final long thanhtien, final boolean damua) {
        this.MaChiTietHD = maChiTietHD;
        this.hoten = hoten;
        this.tensach = tensach;
        this.gia = gia;
        this.SoLuongMua = soLuongMua;
        this.thanhtien = thanhtien;
        this.damua = damua;
    }
    
    public long getMaChiTietHD() {
        return this.MaChiTietHD;
    }
    
    public void setMaChiTietHD(final long maChiTietHD) {
        this.MaChiTietHD = maChiTietHD;
    }
    
    public String getHoten() {
        return this.hoten;
    }
    
    public void setHoten(final String hoten) {
        this.hoten = hoten;
    }
    
    public String getTensach() {
        return this.tensach;
    }
    
    public void setTensach(final String tensach) {
        this.tensach = tensach;
    }
    
    public long getGia() {
        return this.gia;
    }
    
    public void setGia(final long gia) {
        this.gia = gia;
    }
    
    public long getSoLuongMua() {
        return this.SoLuongMua;
    }
    
    public void setSoLuongMua(final long soLuongMua) {
        this.SoLuongMua = soLuongMua;
    }
    
    public long getThanhtien() {
        return this.thanhtien;
    }
    
    public void setThanhtien(final long thanhtien) {
        this.thanhtien = thanhtien;
    }
    
    public boolean isDamua() {
        return this.damua;
    }
    
    public void setDamua(final boolean damua) {
        this.damua = damua;
    }
}