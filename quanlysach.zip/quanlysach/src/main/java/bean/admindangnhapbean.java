package bean;

public class admindangnhapbean
{
    private String TenDangNhap;
    private String MatKhau;
    private boolean Quyen;
    
    public admindangnhapbean() {
    }
    
    public admindangnhapbean(final String tenDangNhap, final String matKhau, final boolean quyen) {
        this.TenDangNhap = tenDangNhap;
        this.MatKhau = matKhau;
        this.Quyen = quyen;
    }
    
    public String getTenDangNhap() {
        return this.TenDangNhap;
    }
    
    public void setTenDangNhap(final String tenDangNhap) {
        this.TenDangNhap = tenDangNhap;
    }
    
    public String getMatKhau() {
        return this.MatKhau;
    }
    
    public void setMatKhau(final String matKhau) {
        this.MatKhau = matKhau;
    }
    
    public boolean isQuyen() {
        return this.Quyen;
    }
    
    public void setQuyen(final boolean quyen) {
        this.Quyen = quyen;
    }
}