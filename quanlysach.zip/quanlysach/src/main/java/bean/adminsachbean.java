package bean;

import java.util.Date;

public class adminsachbean
{
    private String masach;
    private String tensach;
    private long soluong;
    private long gia;
    private String maloai;
    private long sotap;
    private String anh;
    private Date NgayNhap;
    private String tacgia;
    private long thanhtien;
    
    public adminsachbean() {
    }
    
    public adminsachbean(final String masach, final String tensach, final long soluong, final long gia, final String maloai, final long sotap, final String anh, final Date ngayNhap, final String tacgia, final long thanhtien) {
        this.masach = masach;
        this.tensach = tensach;
        this.soluong = soluong;
        this.gia = gia;
        this.maloai = maloai;
        this.sotap = sotap;
        this.anh = anh;
        this.NgayNhap = ngayNhap;
        this.tacgia = tacgia;
        this.thanhtien = thanhtien;
    }
    
    public String getMasach() {
        return this.masach;
    }
    
    public void setMasach(final String masach) {
        this.masach = masach;
    }
    
    public String getTensach() {
        return this.tensach;
    }
    
    public void setTensach(final String tensach) {
        this.tensach = tensach;
    }
    
    public long getSoluong() {
        return this.soluong;
    }
    
    public void setSoluong(final long soluong) {
        this.soluong = soluong;
    }
    
    public long getGia() {
        return this.gia;
    }
    
    public void setGia(final long gia) {
        this.gia = gia;
    }
    
    public String getMaloai() {
        return this.maloai;
    }
    
    public void setMaloai(final String maloai) {
        this.maloai = maloai;
    }
    
    public long getSotap() {
        return this.sotap;
    }
    
    public void setSotap(final long sotap) {
        this.sotap = sotap;
    }
    
    public String getAnh() {
        return this.anh;
    }
    
    public void setAnh(final String anh) {
        this.anh = anh;
    }
    
    public Date getNgayNhap() {
        return this.NgayNhap;
    }
    
    public void setNgayNhap(final Date ngayNhap) {
        this.NgayNhap = ngayNhap;
    }
    
    public String getTacgia() {
        return this.tacgia;
    }
    
    public void setTacgia(final String tacgia) {
        this.tacgia = tacgia;
    }
    
    public long getThanhtien() {
        return this.thanhtien;
    }
    
    public void setThanhtien(final long thanhtien) {
        this.thanhtien = thanhtien;
    }
}