package bo;

import java.util.Iterator;
import bean.loaibean;
import java.util.ArrayList;
import dao.loaidao;

public class loaibo
{
    loaidao ldao;
    ArrayList<loaibean> ds;
    
    public loaibo() {
        this.ldao = new loaidao();
    }
    
    public ArrayList<loaibean> getloai() throws Exception {
        return this.ds = this.ldao.getloai();
    }
    
    public int themloai(final String maloai, final String tenloai) throws Exception {
        final ArrayList<loaibean> ds = this.getloai();
        for (final loaibean loai : ds) {
            if (loai.getMaloai().equals(maloai)) {
                return 0;
            }
        }
        return this.ldao.themloai(maloai, tenloai);
    }
    
    public String Tim(final String maloai) throws Exception {
        for (final loaibean loai : this.ds) {
            if (loai.getMaloai().equals(maloai)) {
                return loai.getTenloai();
            }
        }
        return null;
    }
    
    public int sualoai(final String maloai, final String tenloaimoi) throws Exception {
        return this.ldao.sualoai(maloai, tenloaimoi);
    }
    
    public int xoaloai(final String maLoai) throws Exception {
        return this.ldao.xoaloai(maLoai);
    }
}