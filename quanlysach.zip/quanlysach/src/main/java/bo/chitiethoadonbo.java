package bo;

import bean.adminxacnhanbean;
import java.util.ArrayList;
import dao.chitiethoadondao;

public class chitiethoadonbo
{
    chitiethoadondao cthddao;
    
    public chitiethoadonbo() {
        this.cthddao = new chitiethoadondao();
    }
    
    public int themCTHD(final String masach, final int soLuongMua, final long maHoaDon) throws Exception {
        return this.cthddao.ThemCTHD(masach, soLuongMua, maHoaDon);
    }
    
    public int sua(final long mact) throws Exception {
        return this.cthddao.sua(mact);
    }
    
    public ArrayList<adminxacnhanbean> getxacnhan() throws Exception {
        return this.cthddao.getxacnhan();
    }
    
    public int xoa(final long mact) throws Exception {
        return this.cthddao.xoa(mact);
    }
    
    public int xacnhanHoaDonVaChiTiet(final long mahoadon) throws Exception {
        return this.cthddao.xacnhanHoaDonVaChiTiet(mahoadon);
    }
}
