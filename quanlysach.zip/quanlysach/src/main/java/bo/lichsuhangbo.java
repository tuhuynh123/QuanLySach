package bo;

import bean.lichsubean;
import java.util.ArrayList;
import dao.lichsuhangdao;

public class lichsuhangbo
{
    lichsuhangdao lshdao;
    
    public lichsuhangbo() {
        this.lshdao = new lichsuhangdao();
    }
    
    public ArrayList<lichsubean> getlsu(final long makh) throws Exception {
        return this.lshdao.getlsu(makh);
    }
    
    public void xoahoadonchuatt(final long makh, final int daysAgo) throws Exception {
        this.lshdao.xoahoadonchuatt(makh, daysAgo);
    }
}