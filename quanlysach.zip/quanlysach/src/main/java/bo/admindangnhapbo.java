package bo;

import bean.admindangnhapbean;
import dao.admindangnhapdao;

public class admindangnhapbo
{
    admindangnhapdao admindndao;
    
    public admindangnhapbo() {
        this.admindndao = new admindangnhapdao();
    }
    
    public admindangnhapbean ktdn(final String tendn, final String pass) throws Exception {
        return this.admindndao.ktdn(tendn, pass);
    }
}