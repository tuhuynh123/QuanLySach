
package bo;

import java.util.Iterator;
import java.util.Date;
import bean.adminsachbean;
import java.util.ArrayList;
import dao.adminsachdao;

public class adminsachbo
{
    adminsachdao sdao;
    ArrayList<adminsachbean> ds;
    
    public adminsachbo() {
        this.sdao = new adminsachdao();
    }
    
    public ArrayList<adminsachbean> getsachadmin() throws Exception {
        return this.ds = this.sdao.getsachadmin();
    }
    
    public int themSach(final String masach, final String tensach, final long soluong, final long gia, final String maloai, final long sotap, final String anh, final Date ngayNhap, final String tacgia) throws Exception {
        return this.sdao.themSach(masach, tensach, soluong, gia, maloai, sotap, anh, ngayNhap, tacgia);
    }
    
    public int suaSach(final String masach, final String tensach, final long soluong, final long gia, final String maloai, final long sotap, final String anh, final Date ngayNhap, final String tacgia) throws Exception {
        return this.sdao.suaSach(masach, tensach, soluong, gia, maloai, sotap, anh, ngayNhap, tacgia);
    }
    
    public int xoaSach(final String masach) throws Exception {
        return this.sdao.xoaSach(masach);
    }
    
    public ArrayList<adminsachbean> TimMa(final String maloai) throws Exception {
        final ArrayList<adminsachbean> tam = new ArrayList<adminsachbean>();
        for (final adminsachbean s : this.ds) {
            if (s.getMaloai().equals(maloai)) {
                tam.add(s);
            }
        }
        return tam;
    }
    
    public ArrayList<adminsachbean> TimMS(final String masach) throws Exception {
        final ArrayList<adminsachbean> tam = new ArrayList<adminsachbean>();
        for (final adminsachbean s : this.ds) {
            if (s.getMasach().equals(masach)) {
                tam.add(s);
            }
        }
        return tam;
    }
}
