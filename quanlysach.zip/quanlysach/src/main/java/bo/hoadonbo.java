package bo;

import bean.hoadonbean;
import dao.hoadondao;

public class hoadonbo
{
    hoadondao hddao;
    
    public hoadonbo() {
        this.hddao = new hoadondao();
    }
    
    public int themHD(final long makh) throws Exception {
        return this.hddao.themHD(makh);
    }
    
    public long MaxHD() throws Exception {
        return this.hddao.MaxHD();
    }
    
    public hoadonbean timHD(final long mahd) throws Exception {
        return this.hddao.timHD(mahd);
    }
}
