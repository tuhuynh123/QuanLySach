// 
// Decompiled by Procyon v0.5.36
// 

package bo;

import java.util.Iterator;
import bean.sachbean;
import java.util.ArrayList;
import dao.sachdao;

public class sachbo
{
    sachdao sdao;
    ArrayList<sachbean> ds;
    
    public sachbo() {
        this.sdao = new sachdao();
    }
    
    public ArrayList<sachbean> getsach() throws Exception {
        return this.ds = (ArrayList<sachbean>)this.sdao.getsach();
    }
    
    public int themSach(final String masach, final String tensach, final String tacgia, final long gia, final long soluong, final String anh, final String maloai) throws Exception {
        return this.sdao.themSach(masach, tensach, tacgia, gia, soluong, anh, maloai);
    }
    
    public int suaSach(final String masach, final String tensach, final String tacgia, final long gia, final long soluong, final String anh, final String maloai) throws Exception {
        return this.sdao.suaSach(masach, tensach, tacgia, gia, soluong, anh, maloai);
    }
    
    public int xoaSach(final String masach) throws Exception {
        return this.sdao.xoaSach(masach);
    }
    
    public ArrayList<sachbean> TimMa(final String maloai) throws Exception {
        final ArrayList<sachbean> tam = new ArrayList<sachbean>();
        for (final sachbean s : this.ds) {
            if (s.getMaloai().equals(maloai)) {
                tam.add(s);
            }
        }
        return tam;
    }
    
    public ArrayList<sachbean> Tim(final String key) throws Exception {
        final ArrayList<sachbean> tam = new ArrayList<sachbean>();
        for (final sachbean s : this.ds) {
            if (s.getTensach().toLowerCase().contains(key.toLowerCase()) || s.getTacgia().toLowerCase().contains(key.toLowerCase())) {
                tam.add(s);
            }
        }
        return tam;
    }
    
    public sachbean finByMS(final String masach) throws Exception {
        for (final sachbean s : this.ds) {
            if (s.getMasach().equals(masach)) {
                return s;
            }
        }
        return null;
    }
}