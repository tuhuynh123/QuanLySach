package bo;

import java.util.ArrayList;
import bean.chitietgiohang;
import java.util.List;
import dao.sachdao;

public class CGioHang
{
    sachdao sdao;
    public List<chitietgiohang> ds;
    
    public CGioHang() {
        this.sdao = new sachdao();
        this.ds = new ArrayList<chitietgiohang>();
    }
    
    public void Them(final String ms, final String ts, final int gia, final int sl, final String anh) {
        for (int n = this.ds.size(), i = 0; i < n; ++i) {
            if (this.ds.get(i).getMasach().toLowerCase().trim().equals(ms.toLowerCase().trim())) {
                final int slt = this.ds.get(i).getSoluong() + sl;
                this.ds.get(i).setSoluong(slt);
                final int g = this.ds.get(i).getGia();
                final long tt = slt * (long)g;
                this.ds.get(i).setThanhtien(tt);
                return;
            }
        }
        final chitietgiohang h = new chitietgiohang(ms, ts, gia, sl, anh);
        this.ds.add(h);
    }
    
    public void Sua(final String ms, final int sl) {
        for (int n = this.ds.size(), i = 0; i < n; ++i) {
            if (this.ds.get(i).getMasach().equals(ms)) {
                this.ds.get(i).setSoluong(sl);
                final int gia = this.ds.get(i).getGia();
                final long tt = sl * (long)gia;
                this.ds.get(i).setThanhtien(tt);
                return;
            }
        }
    }
    
    public void Xoa(final String ms) {
        for (int n = this.ds.size(), i = 0; i < n; ++i) {
            if (this.ds.get(i).getMasach().toLowerCase().trim().equals(ms.toLowerCase().trim())) {
                this.ds.remove(i);
                return;
            }
        }
    }
    
    public void XoaTatCa() {
        this.ds.clear();
    }
    
    public void XoaDaChon(final String[] th) {
        for (final String item : th) {
            for (int n = this.ds.size(), i = 0; i < n; ++i) {
                if (this.ds.get(i).getMasach().equalsIgnoreCase(item.trim())) {
                    this.ds.remove(i);
                    break;
                }
            }
        }
    }
    
    public long Tongtien() {
        final int n = this.ds.size();
        long s = 0L;
        for (int i = 0; i < n; ++i) {
            s += this.ds.get(i).getThanhtien();
        }
        return s;
    }
}
