package bo;

import bean.khachhangbean;
import dao.khachhangdao;

public class khachhangbo
{
    khachhangdao khdao;
    
    public khachhangbo() {
        this.khdao = new khachhangdao();
    }
    
    public khachhangbean ktdn(final String tendn, final String pass) throws Exception {
        return this.khdao.ktdn(tendn, pass);
    }
    
    public long them(final String hoten, final String diachi, final String sodt, final String email, final String tendn, final String pass) throws Exception {
        return this.khdao.them(hoten, diachi, sodt, email, tendn, pass);
    }
    
    public khachhangbean kttk(final String tendn) throws Exception {
        return this.khdao.kttk(tendn);
    }
}
